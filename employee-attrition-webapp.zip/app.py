"""
Employee Attrition Predictor — Streamlit Web App
------------------------------------------------
A dashboard UI for the Gradient Boosting attrition model.

BEFORE YOU RUN THIS:
  1. Install dependencies:
       pip install streamlit pandas scikit-learn matplotlib
  2. Make sure "employee_attrition_data.csv" is in this same folder.
  3. Run with:
       streamlit run app.py
     (NOT "python app.py" — Streamlit apps must be launched with the
     "streamlit run" command.)
"""

import pandas as pd
import matplotlib.pyplot as plt
import streamlit as st
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import accuracy_score, recall_score

# ---------------------------------------------------------------------------
# Page config + styling
# ---------------------------------------------------------------------------

st.set_page_config(page_title="Employee Attrition Predictor", page_icon="👥", layout="wide")

st.markdown("""
<style>
    .stApp { background-color: #F4F5F9; }
    section[data-testid="stSidebar"] { background-color: #E6E9F2; }
    div[data-testid="stMetric"] {
        background-color: #FFFFFF;
        border: 1px solid #D6DAEA;
        border-radius: 10px;
        padding: 16px;
    }
    div.stButton > button {
        background-color: #4A5A8C;
        color: #F4F5F9;
        font-weight: 700;
        border: none;
    }
    div.stButton > button:hover {
        background-color: #5D6EA3;
        color: #F4F5F9;
    }
</style>
""", unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# Train the model (cached so it only trains once per session)
# ---------------------------------------------------------------------------

FEATURES = ["Age", "MonthlyIncome", "YearsAtCompany", "JobSatisfaction", "OverTime"]
SATISFACTION_LABELS = {1: "Low", 2: "Medium", 3: "High", 4: "Very High"}


@st.cache_resource
def load_model():
    df = pd.read_csv("employee_attrition_data.csv")

    le_overtime = LabelEncoder()
    le_attrition = LabelEncoder()
    df["OverTime"] = le_overtime.fit_transform(df["OverTime"])
    df["Attrition"] = le_attrition.fit_transform(df["Attrition"])

    X = df[FEATURES]
    y = df["Attrition"]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = GradientBoostingClassifier(n_estimators=150, max_depth=3, learning_rate=0.1, random_state=42)
    model.fit(X_train, y_train)

    pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, pred)
    recall_leavers = recall_score(y_test, pred)
    baseline = (y_test == 0).mean()
    importances = dict(zip(FEATURES, model.feature_importances_))
    return model, le_overtime, accuracy, recall_leavers, baseline, len(df), importances


model, le_overtime, accuracy, recall_leavers, baseline, n_rows, importances = load_model()


# ---------------------------------------------------------------------------
# Sidebar — Model Control
# ---------------------------------------------------------------------------

with st.sidebar:
    st.markdown("## 👥 Model Control")
    st.markdown("### Model Info")
    st.markdown("🔹 **Algorithm:** Gradient Boosting Classifier")
    st.markdown(f"🔹 **Dataset:** Employee Records ({n_rows} rows)")
    st.markdown(f"🔹 **Test Accuracy:** {accuracy*100:.1f}%")
    st.markdown(f"🔹 **Recall on Leavers:** {recall_leavers*100:.1f}%")
    st.caption(f"Baseline (always predict \"stay\"): {baseline*100:.1f}%")

    st.markdown("---")
    st.markdown("### Settings")
    show_probability = st.checkbox("Show attrition probability", value=True)
    show_importance = st.checkbox("Show what drives the model", value=True)


# ---------------------------------------------------------------------------
# Main panel
# ---------------------------------------------------------------------------

st.title("Employee Attrition Predictor")
st.caption("Enter an employee's profile to estimate their risk of leaving.")

st.markdown("---")

col1, col2 = st.columns(2)

with col1:
    st.markdown("### Employee Profile")
    age = st.slider("Age", 21, 60, 32)
    monthly_income = st.number_input("Monthly Income ($)", min_value=1500, max_value=15000, value=5000, step=100)
    years_at_company = st.slider("Years at Company", 0.0, 25.0, 4.0)

with col2:
    st.markdown("### Work Conditions")
    job_satisfaction_label = st.selectbox("Job Satisfaction", ["Low", "Medium", "High", "Very High"])
    job_satisfaction = {"Low": 1, "Medium": 2, "High": 3, "Very High": 4}[job_satisfaction_label]
    overtime = st.selectbox("Works Overtime?", ["Yes", "No"])

st.markdown("---")

if st.button("👥 Predict Attrition Risk", type="primary"):
    overtime_enc = le_overtime.transform([overtime])[0]
    new_employee = pd.DataFrame(
        [[age, monthly_income, years_at_company, job_satisfaction, overtime_enc]],
        columns=FEATURES,
    )
    prediction = model.predict(new_employee)[0]
    proba = model.predict_proba(new_employee)[0][1]

    if prediction == 1:
        st.markdown(
            f"""
            <div style="background-color:#B0433322; border:2px solid #B04333;
                        border-radius:12px; padding:26px; text-align:center; margin-top:10px;">
                <div style="font-size:13px; letter-spacing:2px; color:#6B5A6B; text-transform:uppercase;">
                    Prediction
                </div>
                <div style="font-size:40px; font-weight:bold; color:#B04333; line-height:1.3;">
                    Likely to Leave
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    else:
        st.markdown(
            f"""
            <div style="background-color:#3F6C4C22; border:2px solid #3F6C4C;
                        border-radius:12px; padding:26px; text-align:center; margin-top:10px;">
                <div style="font-size:13px; letter-spacing:2px; color:#6B5A6B; text-transform:uppercase;">
                    Prediction
                </div>
                <div style="font-size:40px; font-weight:bold; color:#3F6C4C; line-height:1.3;">
                    Likely to Stay
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    if show_probability:
        st.metric("Predicted Attrition Probability", f"{proba*100:.1f}%")

    if show_importance:
        st.markdown("#### What drives this model")
        sorted_items = sorted(importances.items(), key=lambda x: -x[1])
        labels = [k for k, v in sorted_items]
        values = [v * 100 for k, v in sorted_items]

        fig, ax = plt.subplots(figsize=(7, 3.2))
        fig.patch.set_facecolor("#F4F5F9")
        ax.set_facecolor("#F4F5F9")
        bars = ax.barh(labels[::-1], values[::-1], color="#4A5A8C", height=0.55, zorder=3)
        for bar, val in zip(bars, values[::-1]):
            ax.text(val + 1.5, bar.get_y() + bar.get_height() / 2, f"{val:.1f}%",
                     va="center", fontsize=11, fontweight="bold", color="#232B42")
        ax.set_xlim(0, max(values) * 1.25)
        ax.tick_params(axis="y", labelsize=11, colors="#232B42")
        ax.tick_params(axis="x", labelsize=9, colors="#6B7590")
        for spine in ["top", "right", "left"]:
            ax.spines[spine].set_visible(False)
        ax.spines["bottom"].set_color("#D6DAEA")
        ax.grid(axis="x", color="#E6E9F2", linewidth=0.7, zorder=0)
        ax.set_axisbelow(True)
        fig.tight_layout()
        st.pyplot(fig)

        st.caption(
            f"Heads up: this model only catches {recall_leavers*100:.0f}% of employees who actually "
            f"leave — a \"Likely to Stay\" result doesn't rule out risk entirely."
        )
